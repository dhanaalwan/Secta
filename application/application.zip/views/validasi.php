<head>
	<link rel="shortcut icon" type="image/x-icon" href="<?=base_url('assets/web/icon.ico');?>" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">

	<title> Sistem E-Control Tugas Akhir</title>
	<script src="<?=base_url('assets/js/fontawesome-all.js');?>">
	</script>
	<link rel="stylesheet" type="text/css" href="<?=base_url('assets/css/bootstrap.min.css');?>">
	
	<script type="text/javascript" src="<?=base_url('assets/js/jquery.js');?>">
	</script>
	
	<script type="text/javascript" src="<?=base_url('assets/js/bootstrap.min.js');?>">
	</script>
	
	<script type="text/javascript" src="<?=base_url('assets/js/sweetalert.min.js');?>">
	</script>

	<script type="text/javascript" src="<?=base_url('assets/js/jquery.validate.min.js');?>">
	</script>

	<script>
		var minutesToAdd=3;
		var currentDate = new Date();
		var countDownDate = new Date(currentDate.getTime() + minutesToAdd*60000);

		var x = setInterval(function() {

		  var now = new Date().getTime();
		    
		  var distance = countDownDate - now;
		    
		  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
		  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
		  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
		    
		  document.getElementById("waktu").innerHTML = minutes + ":" + seconds;
		    
		  if (distance < 0) {
		    clearInterval(x);
		    document.getElementById("waktu").innerHTML = "00:00";
		  }
		}, 1000);
	</script>

</head>

<body style="background-image: url('assets/web/ta3.png'); background-size: cover"
 class="align-items-center">
	<div class="container col-md-5 col-11 col-sm-7" style="height: 100%; display: table;">
		<form id="form-login" action="<?=base_url();?><?=$this->session->userdata('keterangan');?>/validasiproses" method="POST" style="vertical-align: middle; display: table-cell; ">
			<div class="card card-body">

				<h6> Masukkan Kode OTP Yang Terkirim Ke Email Anda</h6>
				<input name="kodeotp" id="kodeotp" type="text" class="form-control form-group" placeholder="Kode OTP">
				
				<button id='btn-login' type="submit" class="btn btn-primary">Login</button>
				<p>
					batas waktu <span id="waktu"></span><br>
					<a href="<?php echo base_url() ?>">Kembali ke Home Login</a>
				</p>
			</div>
		</form>
	</div>
</body>