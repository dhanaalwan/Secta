<head>

</head>

<div class="card card-outline-secondary container table-responsive" style="padding: 50px;">
	<?php if (!$ta && !$ta2) { ?>
		<div class="row align-items-center m-5">
			<div class="col-md mb-5">
				<h2> Tidak Ada Mahasiswa yang Memulai Tugas Akhir </h2>
				Maaf saat ini tidak ada yang memulai Tugas Akhir.

			</div>
			<div class="col-md-3">
				<img src="<?= base_url('assets/web/sad.jpg') ?>">
			</div>
		</div>

	<?php } else if ($ta2){ ?>
		<h5>Tugas Akhir Dengan Penguji</h5>
		<table class="table table-hover" style="margin-bottom: 20px;" id="table-ta" >
			<thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col" style="width:400px;">Judul</th>
                    <th scope="col">Proposal</th>
                    <th scope="col">Tugas Akhir</th>
                    <th scope="col">Ketua Penguji</th>
                    <th scope="col">Penguji 1</th>
                    <th scope="col">Penguji 2</th>
                    <th scope="col">Status</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                	foreach ($ta2->result() as $m) {
                    		
	                        echo '
	                            <tr>
	                            	<td>'.$no.'</td>
	                            	<td>'.$m->Nama.'</td>
	                                <td>'.$m->JudulIde.'</td>
	                                <td>'.$m->LinkProposal.'</td>
	                                <td>'.$m->LinkTugasAkhir.'</td>
	                                <td>'.$m->NamaKetuaPenguji.'</td>
	                                <td>'.$m->NamaPenguji1.'</td>
	                                <td>'.$m->NamaPenguji2.'</td>
	                                <td><span class="badge badge-warning rounded-pill d-inline">'.$m->StatusTA.'</span></td><td>
				                        		<a href="#" class="btn btn-info btn-sm btn-tambah-penguji" data-toggle="modal" data-target="#modal_tambah_penguji" onclick="prepare_tambah('.$m->IDTugasAkhir.','.$m->IDDosen.')">Edit Penguji</a>
				                            </td>
				                        	';
		                        	
	                        	

	                        echo '
	                            </tr>';    
	                                
	                        $npm = $m->ID;
	                        $no++;

                    	
                    }
                    
                    
                ?>
            </tbody>
    	</table>
    	<?php }
    		if ($ta) {
    	?>
    	<h5>Tetapkan Penguji</h5>
    	<table class="table table-hover" id="table-ta2" >
			<thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama</th>
                    <th scope="col" style="width:400px;">Judul</th>
                    <th scope="col">Proposal</th>
                    <th scope="col">Tugas Akhir</th>
                    <th scope="col">Ketua Penguji</th>
                    <th scope="col">Penguji 1</th>
                    <th scope="col">Penguji 2</th>
                    <th scope="col">Status</th>
                    <th scope="col">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                	foreach ($ta->result() as $n) {
                    		
	                        echo '
	                            <tr>
	                            	<td>'.$no.'</td>
	                            	<td>'.$n->Nama.'</td>
	                                <td>'.$n->JudulIde.'</td>
	                                <td>'.$n->LinkProposal.'</td>
	                                <td>'.$n->LinkTugasAkhir.'</td>
	                                <td>-</td>
	                                <td>'.$n->NamaDosen.'</td>
	                                <td>-</td>
	                                <td><span class="badge badge-warning rounded-pill d-inline">'.$n->StatusTA.'</span></td><td>
				                        		<a href="#" class="btn btn-info btn-sm btn-tambah-penguji" data-toggle="modal" data-target="#modal_tambah_penguji" onclick="prepare_tambah('.$n->IDTugasAkhir.','.$n->IDDosen.')">Tambah Penguji</a>
				                            </td>
				                        	';
		                        	
	                        	

	                        echo '
	                            </tr>';    
	                                
	                        $npm = $n->ID;
	                        $no++;

                    	
                    }
                    
                    
                ?>
            </tbody>
    	</table>
    	<?php
    			
    		}
    	?>
    
</div>
<div id="modal_tambah_penguji" class="modal fade" role="dialog">
    <div class="modal-dialog modal-content bg-light rounded h-80 p-4" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    	<div>
    		<div>
		    	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h6 class="mb-4">Tambah Penguji</h6>
	    	</div>
	        <form action="<?= base_url('Adminprodi/tambahPengujiTA') ;?>" method="post">
	        	<div>
	        		<input type="hidden" id="edit_id_ta" name="edit_id_ta">
	        		<input type="hidden" id="edit_pmb" name="edit_pmb">
		            <label>Ketua Penguji</label>
					<select name="edit_pilihan_penguji" id="edit_pilihan_penguji" class="form-control" required>
						<option value="" >Pilih</option>
						<?php
						foreach ($dosen->result() as $d) {
							echo "<option value='" . $d->IDDosen . "'>" . $d->NamaDosen . "</option>";
						}
						?>
					</select>
					<br>

		        </div>
		        <div>
		            <label>Penguji 2</label>
					<select name="edit_pilihan_penguji2" id="edit_pilihan_penguji2" class="form-control" required>
						<option value="" >Pilih</option>
						<?php
						foreach ($dosen->result() as $d) {
							echo "<option value='" . $d->IDDosen . "'>" . $d->NamaDosen . "</option>";
						}
						?>
					</select>
					<br>

		        </div>
		        <div>
			        <input type="submit" class="btn btn-outline-primary" name="submit" value="Simpan">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			      </div>
	            
	        </form>
	    </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>

<script type="text/javascript">
	$(document).ready(function () {
	  $('#table-ta').DataTable();
	  $('#table-ta2').DataTable();

	  // Function to add options to a select element
	  function addOption(select, text, value) {
	    const option = new Option(text, value);
	    select.add(option);
	  }
	  });
	
	function prepare_tambah(id,iddosen)
	{
		$("#edit_id_ta").empty();
		$("#edit_pmb").empty();
		$("#edit_id_ta").val(id);
		$("#edit_pmb").val(id);
	}

	$('.alert-terima').on('click',function(){
            var getLink = $(this).attr('href');
            var getId = $(this).attr('id');
            if (getId == 'tolak') {
            	var pesan = "Yakin tolak ICP?";
            } else{
            	var pesan = "Yakin terima ICP?";
            }
            Swal.fire({
                title: pesan,            
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Ya',
                cancelButtonColor: '#3085d6',
                cancelButtonText: "Batal"
            
            }).then(result => {
                //jika klik ya maka arahkan ke proses.php
                if(result.isConfirmed){
                    window.location.href = getLink
                }
            })
            return false;
        });
	
</script>