<head>
    <script type="text/javascript">
        $('input[type="file"]').on('change', function() {
            var val = $(this).val();
            $(this).siblings('label').text(val);
        });
    </script>
</head>
<div class="grid-container">
	<div class="card container grid-child" style="background-color: white; border: none; padding:30px; margin-bottom: 10px; height: 100%;" >
	<h6>Tambah Kegiatan</h6><br>
	<form method="POST" action="<?= base_url('Adminprodi/tambahKegiatan') ;?>" enctype="multipart/form-data">
		<div class="form-row">
			<div class="form-group col-md col">
				<select name="nama_giat" class="form-control" required>
                    <option value="">Pilih</option>
                    <option value="ICP">ICP</option>
                    <option value="Proposal">Proposal</option>
                    <option value="TA 70%">TA 70%</option>
                    <option value="TA 100%">TA 100%</option>
                </select>
			</div>
		</div>
		<div class="form-row">
			<div class="form-group col-md col">
				<textarea class="form-control form-control-sm"  name="link" id="link" placeholder="Link Pengumpulan" required></textarea>
			</div>
		</div>
        <div class="form-row">
            <div class="form-group col-md col">
                <input class="form-control form-control-sm" type="datetime-local" name="waktu" id="waktu" placeholder="Tenggat Waktu" required>
            </div>
        </div>
        <div class="form-group">
            <div class="input-group">
                <div class="custom-file">
                    <input type="file" id="filegiat" name="filegiat" class="custom-file-input col custom-file-control" enctype="multipart/form-data" required>
                    <label class="custom-file-label">File Kegiatan</label>                   
                </div>
            </div>
            <small>Unggah File Kegiatan</small>

        </div>
		<div>
			<button class="btn btn-outline-primary" type="submit"> Tambah </button>
		</div>

	</form>
	</div>

	<div class='card container grid-child' style="overflow: auto; background-color: white; border: none; padding:30px; margin-bottom: 10px; height: 100%;" >
		<h6 class="mb-4">List Kegiatan</h6>
		<div class="col-sm-12 col-xl-12">
                        <div class="bg-light rounded h-100 p-4">
                            <table class="table table-hover" style="font-size: 12px;">
                                <thead>
                                    <tr>
                                        <th scope="col">No</th>
                                        <th scope="col">Nama Kegiatan</th>
                                        <th scope="col">Link Pengumpulan</th>
                                        <th scope="col">Tenggat Waktu</th>
                                        <th scope="col">File Kegiatan</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $no = 1;
                                        foreach ($kegiatan as $k) {
                                            echo '
                                                <tr>
                                                    <th scope="row">'.$no.'</th>
                                                    <td>'.$k->NamaKegiatan.'</td>
                                                    <td>'.$k->LinkPengumpulan.'</td>
                                                    <td>'.$k->tenggatWaktu.'</td>
                                                    <td>'.$k->FileKegiatan.'</td>
                                                </tr>
                                            ';
                                            $no++;
                                        }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
	</div>
</div>
<style type="text/css">
	.grid-container {
    display: grid;
    grid-template-columns: 1fr 1fr;
    grid-gap: 20px;
    margin-left: 40px;
    margin-right: 40px;
    height: 360px;
}
</style>
