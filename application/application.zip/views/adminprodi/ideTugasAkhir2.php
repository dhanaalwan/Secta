<head>

</head>

<div class="card card-outline-secondary container table-responsive" style="padding: 50px;">
	<?php if (!$idetugasakhir) { ?>
		<div class="row align-items-center m-5">
			<div class="col-md mb-5">
				<h2> Tidak Ada Mahasiswa yang Mengajukan ICP </h2>
				Maaf saat ini tidak ada yang mengajukan idea concept paper.

			</div>
			<div class="col-md-3">
				<img src="<?= base_url('assets/web/sad.jpg') ?>">
			</div>
		</div>

	<?php } else { ?>
		<table class="table table-hover" id="table-ide" style="width: 100%;">
			<thead>
                <tr>
                    <th scope="col">No</th>
                    <th scope="col">Nama Mahasiswa</th>
                    <th scope="col" style="width:300px;">Judul</th>
                    <th scope="col">Link ICP</th>
                    <th scope="col">Dosen</th>
                    <th scope="col">Status</th>
                    <th scope="col" style="width:140px;">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $no = 1;
                    $npm = 0;
                    if (!$mahasiswagroup) {?>
                    	<div class="row align-items-center m-5">
							<div class="col-md mb-5">
								<h2> Tidak Ada Mahasiswa Program Studi <?php echo $id_prodi_user;?> yang Mengajukan ICP </h2>
								Maaf saat ini tidak ada yang mengajukan idea concept paper.
							</div>
							<div class="col-md-3">
								<img src="<?= base_url('assets/web/sad.jpg') ?>">
							</div>
						</div>
                    <?php }else{
                    	foreach ($mahasiswagroup->result() as $m) {
	                    		
		                        echo '
		                            <tr>
		                            	<td>'.$no.'</td>
		                            	<td>'.$m->Nama.'</td>
		                                <td>'.$m->JudulIde.'</td>
		                                <td>'.$m->LinkICP.'</td>
		                                <td>'.$m->NamaDosen.'</td>';
		                        if ($m->StatusIde=='ICP Diajukan') {
		                        	echo '<td><span class="badge badge-warning rounded-pill d-inline">'.$m->StatusIde.'</span></td>';
		                        	if ($m->LinkICP == '') {
		                        		echo '<td><span class="badge badge-danger rounded-pill d-inline">Mahasiswa belum melengkapi link</span></td>';
		                        	} else{
		                        		echo '
			                        	<td>
			                        		<a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal_edit" onclick="prepare_edit_dosen('.$m->IDIde.')"><i class="fas fa-pencil-alt"></i></a>
			                                <a href="'.base_url('Adminprodi/acceptIde/'.$m->IDIde).'" class="alert-terima btn btn-success btn-sm" onclick="">Terima</i></a>
			                                <a href="'.base_url('Adminprodi/rejectIde/'.$m->IDIde).'" class="alert-terima btn btn-danger btn-sm" id="tolak" onclick="">Tolak</i></a>
			                            </td>
			                        	';
		                        	}
		                        } else if ($m->StatusIde=='ICP Diterima' || $m->StatusIde=='ICP Ditolak') {
		                        	if ($m->StatusIde=='ICP Diterima') {
		                        		echo '
		                        			<td><span class="badge badge-success rounded-pill d-inline">'.$m->StatusIde.'</span></td>
		                        		';
		                        	} else if ($m->StatusIde=='ICP Ditolak') {
		                        		echo '
		                        			<td><span class="badge badge-danger rounded-pill d-inline">'.$m->StatusIde.'</span></td>
		                        		';		                        	
		                        	}
		                        	echo '<td>
		                        		<a href="#" class="btn btn-info btn-sm" data-toggle="modal" data-target="#modal_edit" onclick="prepare_edit_dosen('.$m->IDIde.')"><i class="fas fa-pencil-alt"></i></a>
		                        	</td>';
		                        }

		                        echo '
		                            </tr>';    
		                                
		                        $npm = $m->ID;
		                        $no++;
	                    	
	                    }
                    }
                    
                ?>
            </tbody>
    	</table>



    <?php }?>
</div>
<div id="modal_edit" class="modal fade" role="dialog">
	    <div class="modal-dialog modal-content bg-light rounded h-80 p-4" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
	    	<div>
	    		<div>
			    	<button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h6 class="mb-4">Edit Dosen</h6>
		    	</div>
		        <form action="<?= base_url('Adminprodi/adminUpdateIde') ;?>" method="post" class="ideTugasAkhir">
		        	<div>
		        		<input type="hidden" id="edit_id_icp" name="edit_id_icp">
			            <label>Dosen Pembimbing</label>
						<select name="edit_pilihan_dosen" id="edit_pilihan_dosen" class="form-control" required>
							<?php
							foreach ($list_dosen as $d) {
								echo "<option value='" . $d->IDDosen . "'>" . $d->NamaDosen . "</option>";
							}
							?>
						</select>
						<br>

			        </div>
			        <div>
				        <input type="submit" class="btn btn-outline-primary" name="submit" value="Simpan">
				        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				      </div>
		            
		        </form>
		    </div>
	    </div>
	</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>

<script type="text/javascript">
	$(document).ready(function(){
        $('#table-ide').DataTable();
    });
	function prepare_edit_dosen(id)
	{
		$("#edit_id_icp").empty();
		$("#edit_pilihan_dosen").val();

		$.getJSON('<?php echo base_url(); ?>index.php/adminprodi/get_data_ide_by_id/' + id,  function(data){
			$("#edit_id_icp").val(data.IDIde);
			$("#edit_pilihan_dosen").val(data.IDDosen);
		});
	}
		// Swal.fire({
		//   title: 'Are you sure?',
		//   text: "You won't be able to revert this!",
		//   icon: 'warning',
		//   showCancelButton: true,
		//   confirmButtonColor: '#3085d6',
		//   cancelButtonColor: '#d33',
		//   confirmButtonText: 'Yes, delete it!'
		// }).then((result) => {
		//   if (result.isConfirmed) {
		//     Swal.fire(
		//       'Deleted!',
		//       'Your file has been deleted.',
		//       'success'
		//     )
		//   }
		// })
	$('.alert-terima').on('click',function(){
            var getLink = $(this).attr('href');
            var getId = $(this).attr('id');
            if (getId == 'tolak') {
            	var pesan = "Yakin tolak ICP?";
            } else{
            	var pesan = "Yakin terima ICP?";
            }
            Swal.fire({
                title: pesan,            
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                confirmButtonText: 'Ya',
                cancelButtonColor: '#3085d6',
                cancelButtonText: "Batal"
            
            }).then(result => {
                //jika klik ya maka arahkan ke proses.php
                if(result.isConfirmed){
                    window.location.href = getLink
                }
            })
            return false;
        });
</script>