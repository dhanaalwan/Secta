<head>
	<script type="text/javascript">
		$('input[type="file"]').on('change', function() {
			var val = $(this).val();
			$(this).siblings('label').text(val);
		});
	</script>
</head>
<div class="card-body">
	<div class="form-row">
		<div class="form-group col-md">

			<h5> <i class="fas fa-book fa-sm"></i> <?php foreach ($tugasakhir2->result() as $s) {
				echo $s->JudulIde;?> 
			</h5>	

			<!-- <?= word_limiter($s->Deskripsi, 100); } ?> -->

			<div class="form-row mt-3">
				<div class="form-group col-md">

					<?php 
					$statustugasakhir = $tugasakhir2->result()[0]->StatusTA;
					if ($statustugasakhir == 'Kosong' || $statustugasakhir == 'ProposalTerkirim') { 
						$file = $s->LinkProposal;
						$sesi = 'Proposal';
					} else { 
						$file = $s->LinkTugasAkhir;
						$sesi = 'TugasAkhir';
					} $sesi_ta = 0;?>
					<?php 

					$icp = $s->LinkICP;
					$proposal = $s->LinkProposal;
					$tugasakhir = $s->LinkTugasAkhir;

					if (empty($proposal)) {
						$disablep = 'disabled';
					} else {
						$disablep = '';
					}

					if (empty($tugasakhir)) {
						$disables = 'disabled';
					} else {
						$disables = '';
					} 
					?>

					<a class="card-body" href="<?php echo $icp ?>">Link ICP <i class="bi bi-box-arrow-up-right"></i></a>

					<a class="card-body" <?php if (empty($proposal)) {
						echo "";
					} else {
						echo "href=".base_url("ControllerGlobal/downloadFile/Proposal/".$proposal);
					} ?>> Link Proposal <i class="bi bi-box-arrow-up-right"></i>  </a>

					<a class="card-body" <?php if (empty($tugasakhir)) {
						echo "";
					} else {
						echo "href=".base_url("ControllerGlobal/downloadFile/TugasAkhir/".$tugasakhir);
					} ?>> Link Tugas Akhir <i class="bi bi-box-arrow-up-right"></i> </a>

				</div>
				
			</div>
		</div>
		<div class="form-group">
			<div class=" float-right">
				<a href="<?php echo base_url('Cetak/kartu/').$this->session->userdata('ID');?>"> <button class="btn btn-outline-primary btn-sm"> <i class="fas fa-print"> </i> Cetak </button> </a>	
			</div>
		</div>
	</div>
	<div class="row">
		<div class="col-sm-6" style="height:440px; margin-bottom: 20px;">
			<div class="prp card bg-warning mb-3" style="height:100%;">
				<div class="card-header" style="color:black;"><strong>PROPOSAL</strong></div>
				<div class="card-body m-3">
					<table style="margin-bottom: 10px; vertical-align:top;">
						<tbody>
							<tr>
								<td style="width: 30%;"><strong>Nama</strong></td>
								<td style="width: 7%;">:</td>
								<td><?php echo $tugasakhir2->result()[0]->Nama?></td>
							</tr>
							<tr>
								<td><strong>NPM</strong></td>
								<td>:</td>
								<td><?php echo $tugasakhir2->result()[0]->ID?></td>
							</tr>
							<tr>
								<td><strong>Judul Proposal</strong></td>
								<td>:</td>
								<td><?php echo $tugasakhir2->result()[0]->JudulIde?></td>
							</tr>
							<tr>
								<td><strong>File Proposal</strong></td>
								<td>:</td>
								<td>
									<?php if ($tugasakhir2->result()[0]->FileProposal!=''){?>
										<?php echo $tugasakhir2->result()[0]->FileProposal?>
									<?php } else{?>
										-
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Ketua Penguji</strong></td>
								<td>:</td>
								<td>
									<?php if ($ketuapenguji->result()[0]->IDKetuaPenguji == NULL){?>
										-
									<?php } else{?>
										<?php echo $ketuapenguji->result()[0]->NamaDosen?>
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Penguji 1</strong></td>
								<td>:</td>
								<td><?php echo $dosenpembimbing->result()[0]->NamaDosen?></td>
							</tr>
							<tr>
								<td><strong>Penguji 2</strong></td>
								<td>:</td>
								<td>
									<?php if ($penguji2->result()[0]->IDPenguji2 == NULL){?>
										-
									<?php } else{?>
										<?php echo $penguji2->result()[0]->NamaDosen?>
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Tenggat Waktu</strong></td>
								<td>:</td>
								<td>

									<?php 
									if ($sesi == 'Proposal'){
										if (!$waktuproposal){
											echo '-';
										} else{
											echo $waktuproposal->result()[0]->tenggatWaktu;
										}
									} else{
										echo '-';
									}?>
								</td>
							</tr>
						</tbody>
					</table>

				    <?php 
				    if ($sesi == 'Proposal') {
				    	if ($statustugasakhir == 'Kosong'): ?>
						<div class="form-group mr-3">
							<form method="post" id="mydata" action="<?php echo base_url('Mahasiswa/uploadData/'.$sesi.'/'.$s->IDTugasAkhir.'/ProposalTerkirim');?>" enctype="multipart/form-data">
								<div class="input-group">
									<div class="custom-file">
										<input type="file" name="Proposal" id="Proposal" class="custom-file-input col custom-file-control" required>
										<label class="custom-file-label">Upload <?= $sesi ?></label>					
									</div>
									<div class="input-group-append"> 
										<button class="btn btn-outline-primary" type="submit"> Upload </button>					
									</div>
								</div>
								<small> File harus berbentuk PDF </small>
							</form>		
						</div>
						<h5><span class="badge badge-secondary">Proposal Belum Diupload</span></h5>
					<?php endif ?>
					<?php if ($statustugasakhir == 'ProposalTerkirim'): ?>
						<h5><span class="badge badge-success">Proposal Sudah Dikirim ke Dosen</span></h5>
						<a href="#" class="btn btn-primary btn-sm text-white" data-toggle="modal" data-target="#modal_kumpulkan_proposal">Kumpulkan Proposal ke Drive</a>
					<?php endif;
					
				    } else{

				    	echo '
				    		<h5><span class="badge badge-success">Proposal Sudah Dikumpulkan ke Drive</span></h5>
				    	';?>

				    	<script type="text/javascript">
				    		$(document).ready(function(){
							   $('.prp').addClass('bg-light text-dark').removeClass('text-white bg-warning');

							});
				    	</script>
				    <?php }?>
				    
			  	</div>

			</div>
		</div>
		<div class="col-sm-6" style="height:440px; margin-bottom: 20px;">
			<div class="ta card text-white bg-info mb-3" style="height:100%;">
				<div class="card-header" style="color:black;"><strong>TUGAS AKHIR</strong></div>
								<div class="card-body m-3">
					<table style="margin-bottom: 10px; vertical-align:top;">
						<tbody>
							<tr>
								<td style="width: 30%;"><strong>Nama</strong></td>
								<td style="width: 7%;">:</td>
								<td><?php echo $tugasakhir2->result()[0]->Nama?></td>
							</tr>
							<tr>
								<td><strong>NPM</strong></td>
								<td>:</td>
								<td><?php echo $tugasakhir2->result()[0]->ID?></td>
							</tr>
							<tr>
								<td><strong>Judul</strong></td>
								<td>:</td>
								<td><?php echo $tugasakhir2->result()[0]->JudulIde?></td>
							</tr>
							<tr>
								<td><strong>File Tugas Akhir</strong></td>
								<td>:</td>
								<td>
									<?php if ($tugasakhir2->result()[0]->FileTugasAkhir!=''){?>
										<?php echo $tugasakhir2->result()[0]->FileTugasAkhir?>
									<?php } else{?>
										-
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Ketua Penguji</strong></td>
								<td>:</td>
								<td>
									<?php if ($ketuapenguji->result()[0]->IDKetuaPenguji == NULL){?>
										-
									<?php } else{?>
										<?php echo $ketuapenguji->result()[0]->NamaDosen?>
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Penguji 1</strong></td>
								<td>:</td>
								<td><?php echo $dosenpembimbing->result()[0]->NamaDosen?></td>
							</tr>
							<tr>
								<td><strong>Penguji 2</strong></td>
								<td>:</td>
								<td>
									<?php if ($penguji2->result()[0]->IDPenguji2 == NULL){?>
										-
									<?php } else{?>
										<?php echo $penguji2->result()[0]->NamaDosen?>
									<?php }?>
								</td>
							</tr>
							<tr>
								<td><strong>Tenggat Waktu</strong></td>
								<td>:</td>
								<td>
									<?php 
									if ($sesi == 'TugasAkhir'){
										if ($statustugasakhir == 'ProposalDikumpulkan'||$statustugasakhir == 'TugasAkhir70Terkirim') {
											if (!$waktuta70) {
												echo '-';
											} else {
												echo $waktuta70->result()[0]->tenggatWaktu;
											}

											
										} elseif($statustugasakhir == 'TugasAkhir70Dikumpulkan'||$statustugasakhir == 'TugasAkhir100Terkirim'||$statustugasakhir == 'TugasAkhir100Dikumpulkan'){
											if (!$waktuta100) {
												echo '-';
											} else {
												echo $waktuta100->result()[0]->tenggatWaktu;
											}
										}
									} else {
										echo '-';
									}?>
								</td>
							</tr>
						</tbody>
					</table>

				    <?php 
				    if ($sesi == 'TugasAkhir') {
				    	if ($statustugasakhir == 'ProposalDikumpulkan'): ?>
						<div class="form-group mr-3">
							<form method="post" id="mydata" action="<?php echo base_url('Mahasiswa/uploadData/'.$sesi.'/'.$s->IDTugasAkhir.'/TugasAkhir70Terkirim');?>" enctype="multipart/form-data">
								<div class="input-group">
									<div class="custom-file">
										<input type="file" name="TugasAkhir" id="TugasAkhir" class="custom-file-input col custom-file-control" required>
										<label class="custom-file-label">Upload <?= $sesi ?> 70%</label>					
									</div>
									<div class="input-group-append"> 
										<button class="btn btn-outline-dark" type="submit"> Upload </button>					
									</div>
								</div>
								<small> File harus berbentuk PDF </small>
							</form>		
						</div>
						<h5><span class="badge badge-secondary">TA 70% Belum Diupload</span></h5>
					<?php endif ?>
					<?php if ($statustugasakhir == 'TugasAkhir70Terkirim'): ?>
						<h5><span class="badge badge-secondary">TA 70% Sudah Dikirim ke Dosen</span></h5>
						<a href="#" class="btn btn-light btn-sm" data-toggle="modal" data-target="#modal_kumpulkan_ta70">Kumpulkan TA 70% ke Drive</a>
					<?php endif ?>
					<?php if ($statustugasakhir == 'TugasAkhir70Dikumpulkan'): ?>
						<div class="form-group mr-3">
							<form method="post" id="mydata" action="<?php echo base_url('Mahasiswa/uploadData/TugasAkhir100/'.$s->IDTugasAkhir.'/TugasAkhir100Terkirim');?>" enctype="multipart/form-data">
								<div class="input-group">
									<div class="custom-file">
										<input type="file" name="TugasAkhir100" id="TugasAkhir100" class="custom-file-input col custom-file-control" required>
										<label class="custom-file-label">Upload <?= $sesi ?> 100%</label>					
									</div>
									<div class="input-group-append"> 
										<button class="btn btn-outline-dark" type="submit"> Upload </button>					
									</div>
								</div>
								<small> File harus berbentuk PDF </small>
							</form>		
						</div>
						<h5><span class="badge badge-success">TA 70% Sudah Dikumpulkan ke Drive</span></h5>
						<h5><span class="badge badge-secondary">TA 100% Belum Diupload</span></h5>
					<?php endif; ?>
					<?php if ($statustugasakhir == 'TugasAkhir100Terkirim'): ?>
						<h5><span class="badge badge-secondary">TA 100% Sudah Dikirim ke Dosen</span></h5>
						<a href="#" class="btn btn-primary btn-sm text-white" data-toggle="modal" data-target="#modal_kumpulkan_ta100">Kumpulkan TA 100% ke Drive</a>
					<?php endif ?>
					<?php if ($statustugasakhir == 'TugasAkhir100Dikumpulkan'): ?>
						<h5><span class="badge badge-success">TA 100% Sudah Dikumpulkan ke Drive</span></h5>
						<script type="text/javascript">
				    		$(document).ready(function(){
							   $('.ta').addClass('bg-light text-dark').removeClass('text-white bg-info');

							});
				    	</script>
					<?php endif; 
				    } else{

				    	echo '
				    		<h5><span class="badge badge-secondary">Kosong</span></h5>
				    	';?>

				    	<script type="text/javascript">
				    		$(document).ready(function(){
							   $('.ta').addClass('bg-light text-dark').removeClass('text-white bg-info');

							});
				    	</script>
				    <?php }?>
				    
			  	</div>

			</div>
		</div>
	</div>

	<div class="card border-primary mb-3">
	  <div class="card-header">Link Pengumpulan</div>
	  <div class="card-body text-primary">
	    <h6 class="card-title text-primary">
	    	<?php if ($waktuproposal){
	    		echo '
	    			<a href="'.$waktuproposal->result()[0]->LinkPengumpulan.'" target="_blank">
	    		';
	    	}else{
	    		echo '
	    			<a href="#">
	    		';
	    	}
	    	?>
	    	
	    		Pengumpulan Proposal
	    	</a>
		</h6>
	    <h6 class="card-title text-primary">
	    	<?php if ($waktuta70){
	    		echo '
	    			<a href="'.$waktuta70->result()[0]->LinkPengumpulan.'" target="_blank">
	    		';
	    	}else{
	    		echo '
	    			<a href="#">
	    		';
	    	}
	    	?>Pengumpulan TA 70%</a>
	    </h6>
	    <h6 class="card-title text-primary">
	    	<?php if ($waktuta100){
	    		echo '
	    			<a href="'.$waktuta100->result()[0]->LinkPengumpulan.'" target="_blank">
	    		';
	    	}else{
	    		echo '
	    			<a href="#">
	    		';
	    	}
	    	?>Pengumpulan TA 100%</a></h6>
	  </div>
	</div>


	<!-- <div class="form-row table-responsive" id="tugasakhir">		
		<table class="table table-borderless table-sm">
			<thead class="small">
				<tr>
					<th> Nama </th>
					<th class="text-center"> Proposal </th>
					<th class="text-center">Tugas Akhir</th>
					<th >Status Pembimbing</th>
				</tr>
			</thead>
			<?php 
			if($pembimbing){
			foreach ($pembimbing->result() as $p) { ?>
				<tbody class="small"> 
					<td><?php echo $p->Nama; ?></td>
					<td class="text-center"><?php if ($p->StatusProposal) {
						echo "<i class='fas fa-check-square'></i>";
					} else {
						echo "<i class='fas fa-square'></i>";
					} ?></td>
					<td class="text-center"><?php if ($p->StatusTugasAkhir) {
						echo "<i class='fas fa-check-square'></i>";
					} else {
						echo "<i class='fas fa-square'></i>";
					} ?></td>
					<td><?php echo 'Pembimbing '?></td>
				</tbody>
			<?php }} ?>
		</table>
	</div> -->
	<?php if (!$konsultasi) { ?>
		<div class="card card-outline-secondary">
			<div class="row align-items-center m-5">
				<div class="col-md mb-5">
					<h2>Belum Ada Catatan Bimbingan</h2>
					Catatan bimbingan belum di isi oleh pembimbing, jika anda pembimbing silahkan isi catatan bimbingan mahasiswa ini dengan memasukan form catatan di atas. tanggal bimbingan akan secara otomatis masuk saat anda memasukan catatan saat itu juga.
				</div>
				<div class="col-md-auto">
					<img style="height: 10rem" src="<?= base_url('assets/web/sad.jpg') ?>" >	
				</div>
			</div>

		</div>
	<?php } else { ?>
		<div id="table-wrapper">
			<div class="mt-2" style="overflow:auto; height: 16rem">
				<table class="table table-sm small">
					<thead>
						<tr>
							<th style='width: 5rem'>No</th>
							<th style="width: 12rem">Tanggal</th>
							<th>Pembimbing</th>
						</tr>
					</thead>
					<tbody>
						<?php if (!empty($konsultasi)): ?>
							<?php $no = '1'; ?>
							<?php foreach ($konsultasi->result() as $k) {	?>
								<tr>
									<td><?php echo $no++;?></td>
									<td><?php echo longdate_indo($k->TanggalBimbingan);?></td>
									<td><?php echo $k->Nama;?></td>
								</tr>
								<tr>
									<th>Catatan</th>
									<td colspan="3"><?php echo $k->Catatan;?></td>
								</tr>
							<?php } ?>
						<?php endif ?>
					</tbody>	
				</table>
			</div>
		</div>
	<?php } ?>
</div>
<div id="modal_kumpulkan_proposal" class="modal fade" role="dialog">
    <div class="modal-dialog modal-content bg-light rounded h-80 p-4" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    	<div>
    		<div>
		    	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h6 class="mb-4">Kumpulkan Proposal</h6>
	    	</div>
	        <form action="<?= base_url('Mahasiswa/sendLink/'.$tugasakhir2->result()[0]->IDTugasAkhir.'/'.$sesi.'/ProposalDikumpulkan') ;?>" method="post">
	        	<div>
		            <div class="mb-3">
		                <label for="link" class="form-label">Link Pengumpulan Proposal</label>
		                <input type="text" class="form-control" id="link" name="link" aria-describedby="linkHelp">
                        <div id="linkHelp" class="form-text">Inputkan link dokumen PROPOSAL yang telah dikumpulkan pada drive.
                        </div>
		            </div>

		        </div>
		        <div>
			        <input type="submit" class="btn btn-outline-primary" name="submit" value="Simpan">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			      </div>
	            
	        </form>
	    </div>
    </div>
</div>
<div id="modal_kumpulkan_ta70" class="modal fade" role="dialog">
    <div class="modal-dialog modal-content bg-light rounded h-80 p-4" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    	<div>
    		<div>
		    	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h6 class="mb-4">Kumpulkan Tugas Akhir</h6>
	    	</div>
	        <form action="<?= base_url('Mahasiswa/sendLink/'.$tugasakhir2->result()[0]->IDTugasAkhir.'/'.$sesi.'/TugasAkhir70Dikumpulkan') ;?>" method="post">
	        	<div>
		            <div class="mb-3">
		                <label for="link" class="form-label">Link Pengumpulan TA 70%</label>
		                <input type="text" class="form-control" id="link" name="link" aria-describedby="linkHelp">
                        <div id="linkHelp" class="form-text">Inputkan link dokumen TUGAS AKHIR 70% yang telah dikumpulkan pada drive.
                        </div>
		            </div>

		        </div>
		        <div>
			        <input type="submit" class="btn btn-outline-primary" name="submit" value="Simpan">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			      </div>
	            
	        </form>
	    </div>
    </div>
</div>
<div id="modal_kumpulkan_ta100" class="modal fade" role="dialog">
    <div class="modal-dialog modal-content bg-light rounded h-80 p-4" style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%);">
    	<div>
    		<div>
		    	<button type="button" class="close" data-dismiss="modal">&times;</button>
		        <h6 class="mb-4">Kumpulkan Tugas Akhir</h6>
	    	</div>
	        <form action="<?= base_url('Mahasiswa/sendLink/'.$tugasakhir2->result()[0]->IDTugasAkhir.'/'.$sesi.'/TugasAkhir100Dikumpulkan') ;?>" method="post">
	        	<div>
		            <div class="mb-3">
		                <label for="link" class="form-label">Link Pengumpulan TA 100%</label>
		                <input type="text" class="form-control" id="link" name="link" aria-describedby="linkHelp">
                        <div id="linkHelp" class="form-text">Inputkan link dokumen TUGAS AKHIR 100% yang telah dikumpulkan pada drive.
                        </div>
		            </div>

		        </div>
		        <div>
			        <input type="submit" class="btn btn-outline-primary" name="submit" value="Simpan">
			        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			      </div>
	            
	        </form>
	    </div>
    </div>
</div>